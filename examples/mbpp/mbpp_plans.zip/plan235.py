def check_monthnumb_number(month_number):
    # Months with 31 days: January, March, May, July, August, October, December
    months_with_31_days = {1, 3, 5, 7, 8, 10, 12}
    return month_number in months_with_31_days
