def remove_odd(input_string: str) -> str:
    # Check if the input is a string
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string")
    
    # Use string slicing to remove characters at odd indices
    return input_string[1::2]