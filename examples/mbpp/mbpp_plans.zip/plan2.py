def find_Volume(base, height, length):
    """
    Calculate the volume of a triangular prism.

    Parameters:
    base (float or int): The base of the triangular face of the prism.
    height (float or int): The height of the triangular face of the prism.
    length (float or int): The length of the prism.

    Returns:
    float or int: The volume of the triangular prism.
    """
    return 0.5 * base * height * length
