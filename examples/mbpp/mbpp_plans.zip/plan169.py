def maximum(a: float, b: float) -> float:
    return max(a, b)