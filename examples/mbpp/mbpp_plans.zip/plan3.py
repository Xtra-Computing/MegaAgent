import re

def text_lowercase_underscore(s: str) -> bool:
    # Regular expression to match sequences of lowercase letters joined by an underscore
    pattern = r'^[a-z]+(_[a-z]+)+$'
    return bool(re.match(pattern, s))
