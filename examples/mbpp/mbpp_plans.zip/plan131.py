def list_split(lst: list, n: int) -> list:
    # Input Validation
    if n <= 0:
        raise ValueError("n must be greater than 0")
    if not lst:
        return []

    # Initialize Result Structure
    result = [[] for _ in range(n)]

    # Populate Sublists
    for index, element in enumerate(lst):
        result[index % n].append(element)

    # Return Result
    return result
