import math

def lateralsuface_cylinder(radius: float, height: float) -> float:
    return 2 * math.pi * radius * height
