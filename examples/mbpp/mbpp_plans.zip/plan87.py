import math

def area_polygon(n: int, s: float) -> float:
    if n < 3:
        raise ValueError("The number of sides must be at least 3.")
    if s <= 0:
        raise ValueError("The side length must be positive.")
    area = (n * s**2) / (4 * math.tan(math.pi / n))
    return area
