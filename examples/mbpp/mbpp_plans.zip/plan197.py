def overlapping(seq1, seq2):
    """
    Check if there is any common element in two sequences.

    Parameters:
    seq1 (sequence): The first sequence to check.
    seq2 (sequence): The second sequence to check.

    Returns:
    bool: True if there is at least one common element, False otherwise.
    """
    # Convert both sequences to sets
    set1 = set(seq1)
    set2 = set(seq2)
    
    # Check for intersection
    return not set1.isdisjoint(set2)