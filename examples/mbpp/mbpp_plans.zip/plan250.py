def tuple_intersection(list1, list2):
    # Normalize tuples in both lists
    normalized_list1 = {tuple(sorted(t)) for t in list1}
    normalized_list2 = {tuple(sorted(t)) for t in list2}
    
    # Find intersection of the two sets
    intersection = normalized_list1.intersection(normalized_list2)
    
    return intersection
