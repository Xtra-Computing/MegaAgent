def rearrange_bigger(n):
    # Validate input
    if not (1 <= n <= 10**9):
        raise ValueError("Input must be within the range [1, 10^9]")

    # Convert number to list of digits
    digits = list(str(n))
    length = len(digits)

    # Edge case: single-digit number
    if length == 1:
        return False

    # Traverse the list from the end to find the first decreasing element
    i = length - 2
    while i >= 0 and digits[i] >= digits[i + 1]:
        i -= 1

    # If no such element is found, return False
    if i == -1:
        return False

    # Find the smallest element on the right of 'i' that is larger than digits[i]
    j = length - 1
    while digits[j] <= digits[i]:
        j -= 1

    # Swap the found elements
    digits[i], digits[j] = digits[j], digits[i]

    # Reverse the sequence from i+1 to end
    digits = digits[:i+1] + digits[i+1:][::-1]

    # Convert back to integer
    result = int(''.join(digits))

    return result if result > n else False
