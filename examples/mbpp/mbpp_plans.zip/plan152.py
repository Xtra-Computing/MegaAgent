def square_Sum(n):
    # Generate the first n even numbers and calculate their squares
    even_squares = [(2 * i) ** 2 for i in range(1, n + 1)]
    # Return the sum of the squares
    return sum(even_squares)