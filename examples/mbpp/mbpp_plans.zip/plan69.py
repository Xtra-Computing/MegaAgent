def long_words(n: int, sentence: str) -> list:
    # Split the sentence into words
    words = sentence.split()
    
    # Filter words longer than n characters
    long_words_list = [word for word in words if len(word) > n]
    
    return long_words_list
