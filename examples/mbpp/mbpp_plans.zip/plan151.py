from typing import List

# Function to find the largest sum of a contiguous subarray in the modified array
# which is formed by repeating the given array k times.
def max_sub_array_sum_repeated(arr: List[int], n: int, k: int) -> int:
    # Helper function to use Kadane's algorithm
    def kadane(arr: List[int]) -> int:
        max_ending_here = max_so_far = arr[0]
        for x in arr[1:]:
            max_ending_here = max(x, max_ending_here + x)
            max_so_far = max(max_so_far, max_ending_here)
        return max_so_far

    # Calculate the maximum subarray sum using Kadane's algorithm
    max_kadane = kadane(arr)

    # If k is 1, return the result from Kadane's algorithm
    if k == 1:
        return max_kadane

    # Calculate the total sum of the array
    total_sum = sum(arr)

    # Calculate the maximum prefix sum
    max_prefix_sum = float('-inf')
    current_prefix_sum = 0
    for i in range(n):
        current_prefix_sum += arr[i]
        max_prefix_sum = max(max_prefix_sum, current_prefix_sum)

    # Calculate the maximum suffix sum
    max_suffix_sum = float('-inf')
    current_suffix_sum = 0
    for i in range(n-1, -1, -1):
        current_suffix_sum += arr[i]
        max_suffix_sum = max(max_suffix_sum, current_suffix_sum)

    # Calculate the maximum sum considering the wrap-around effect
    max_wrap = max_suffix_sum + max_prefix_sum + (k-2) * total_sum

    # Return the maximum of the calculated sums
    return max(max_kadane, max_wrap)
