def intersection_array(list1, list2):
    # Initialize an empty set to track elements already added to the result
    result_set = set()
    # Initialize an empty list to store the result
    result_list = []
    # Iterate through each element in list1
    for element in list1:
        # Check if the element is in list2 and not already in the result set
        if element in list2 and element not in result_set:
            # Add the element to the result list and result set
            result_list.append(element)
            result_set.add(element)
    # Return the result list
    return result_list
