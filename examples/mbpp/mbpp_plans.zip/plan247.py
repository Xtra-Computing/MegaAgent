def add_pairwise(input_tuple):
    # Step 1: Validation
    if not isinstance(input_tuple, tuple) or len(input_tuple) < 2:
        raise ValueError("Input must be a tuple with at least two elements.")
    
    # Step 2-4: Iteration, Addition, and Construction
    result = tuple(input_tuple[i] + input_tuple[i + 1] for i in range(len(input_tuple) - 1))
    
    # Step 5: Return
    return result
