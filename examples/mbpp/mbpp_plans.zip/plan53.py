def add_lists(list_to_append, tuple_to_extend):
    # Convert the list to a tuple
    list_as_tuple = tuple(list_to_append)
    
    # Concatenate the original tuple with the new tuple created from the list
    result_tuple = tuple_to_extend + list_as_tuple
    
    # Return the concatenated tuple
    return result_tuple
