def set_left_most_unset_bit(n: int) -> int:
    # If n is 0, the left-most unset bit is the first bit
    if n == 0:
        return 1

    # Find the position of the left-most unset bit
    position = 0
    temp = n
    while temp & 1:
        position += 1
        temp >>= 1

    # Set the left-most unset bit
    return n | (1 << position)