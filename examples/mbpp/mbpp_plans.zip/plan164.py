from typing import List

def find_Element(arr: List[int], rotations: List[List[int]], num_rotations: int, index: int) -> int:
    # Perform the specified number of rotations
    for i in range(num_rotations):
        start, end = rotations[i]
        # Perform a right rotation on the sublist from start to end
        if end > start:
            arr = arr[:start] + [arr[end]] + arr[start:end] + arr[end+1:]
    
    # Return the element at the specified index
    return arr[index]
