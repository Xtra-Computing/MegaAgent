# -*- coding: utf-8 -*-

def newman_prime(n):
    # Base cases
    if n == 1 or n == 2:
        return 1

    # List to store the sequence
    nsw_sequence = [1, 1]

    # Generate the sequence up to the nth term
    for i in range(2, n):
        next_nsw = 2 * nsw_sequence[i - 1] + nsw_sequence[i - 2]
        nsw_sequence.append(next_nsw)

    # Find the nth Newman�CShanks�CWilliams prime
    count = 0
    for num in nsw_sequence[2:]:  # Start checking from the third element
        if is_prime(num):
            count += 1
            if count == n - 2:  # Adjust for the first two 1s
                return num

    return None


def is_prime(num):
    if num <= 1:
        return False
    if num <= 3:
        return True
    if num % 2 == 0 or num % 3 == 0:
        return False
    i = 5
    while i * i <= num:
        if num % i == 0 or num % (i + 2) == 0:
            return False
        i += 6
    return True
