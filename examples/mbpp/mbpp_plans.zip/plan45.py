import math

def multiply_num(numbers: list) -> float:
    if not numbers:
        raise ValueError("The input list is empty.")
    
    product = 1
    for number in numbers:
        product *= number
    
    length = len(numbers)
    result = product / length
    
    return float(result)

# Test cases
assert math.isclose(multiply_num((8, 2, 3, -1, 7)), -67.2, rel_tol=0.001)
assert math.isclose(multiply_num((-10,-20,-30)), -2000.0, rel_tol=0.001)
assert math.isclose(multiply_num((19,15,18)), 1710.0, rel_tol=0.001)