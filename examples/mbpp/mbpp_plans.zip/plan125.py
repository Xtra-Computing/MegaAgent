def swap_numbers(num1, num2):
    return (num2, num1)