def rear_extract(tuples_list: list) -> list:
    rear_elements = []
    for tup in tuples_list:
        rear_elements.append(tup[-1])
    return rear_elements
