def sequential_search(array: list, element: any) -> tuple:
    for index, current_element in enumerate(array):
        if current_element == element:
            return (True, index)
    return (False, -1)