def is_Diff(n: int) -> bool:
    # Convert the number to a string to access each digit
    n_str = str(n)
    
    # Initialize the alternating sum
    alternating_sum = 0
    
    # Iterate over each digit
    for i, char in enumerate(n_str):
        digit = int(char)
        
        # Add or subtract the digit based on its position
        if i % 2 == 0:
            alternating_sum += digit
        else:
            alternating_sum -= digit
    
    # Check if the alternating sum is divisible by 11
    return alternating_sum % 11 == 0