import cmath

def convert(z):
    # Calculate the magnitude and phase angle using cmath.polar
    r, theta = cmath.polar(z)
    return (r, theta)