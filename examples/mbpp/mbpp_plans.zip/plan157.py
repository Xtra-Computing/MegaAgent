def max_val(input_list: list) -> int:
    # Step 1: Filter Integers
    integers = [item for item in input_list if isinstance(item, int)]
    
    # Step 2: Find Maximum
    max_value = max(integers)
    
    # Step 3: Return Result
    return max_value
