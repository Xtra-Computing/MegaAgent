def is_lower(input_string: str) -> str:
    return input_string.lower()