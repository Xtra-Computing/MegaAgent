def even_Power_Sum(n):
    # Initialize the sum accumulator
    total_sum = 0
    
    # Loop through the first n even natural numbers
    for i in range(1, n + 1):
        even_number = 2 * i
        # Calculate the fifth power of the even number
        fifth_power = even_number ** 5
        # Accumulate the sum
        total_sum += fifth_power
    
    # Return the accumulated sum
    return total_sum