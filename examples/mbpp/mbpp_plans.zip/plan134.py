def find_star_num(n: int) -> int:
    """
    Calculate the n'th star number.

    Parameters:
    n (int): The position in the sequence of star numbers.

    Returns:
    int: The n'th star number.
    """
    return 6 * n * (n - 1) + 1
