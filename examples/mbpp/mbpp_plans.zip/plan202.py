def cube_Sum(n):
    # Calculate the sum of cubes of the first n even natural numbers
    return sum((2 * i) ** 3 for i in range(1, n + 1))
