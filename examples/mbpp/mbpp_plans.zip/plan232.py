def loss_amount(cost_price, selling_price):
    # If selling price is greater than or equal to cost price, return 0
    if selling_price >= cost_price:
        return 0
    # Otherwise, return the loss amount
    return cost_price - selling_price
