def pos_count(numbers: list) -> int:
    # Use list comprehension to filter positive numbers and return their count
    return len([num for num in numbers if num > 0])
