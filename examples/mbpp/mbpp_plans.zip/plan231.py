def remove_whitespaces(input_string: str) -> str:
    return input_string.replace(' ', '')