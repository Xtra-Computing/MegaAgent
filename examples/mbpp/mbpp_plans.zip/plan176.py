def convert_list_dictionary(list1, list2, list3):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate over the indices of the input lists
    for i in range(len(list1)):
        # Create a dictionary for each index
        outer_dict = {list1[i]: {list2[i]: list3[i]}}
        # Append the dictionary to the result list
        result.append(outer_dict)
    
    # Return the final list of dictionaries
    return result
