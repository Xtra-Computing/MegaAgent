def harmonic_sum(n: int) -> float:
    """
    Calculate the harmonic sum of n-1.

    Parameters:
    n (int): The integer input for which the harmonic sum of n-1 is calculated.

    Returns:
    float: The harmonic sum of n-1.
    """
    if n <= 1:
        return 0.0
    return sum(1.0 / i for i in range(1, n))
