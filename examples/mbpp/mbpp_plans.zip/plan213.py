def median_trapezium(a, b, h):
    """
    Calculate the median length of a trapezium.

    Parameters:
    a (float or int): The length of the first parallel side of the trapezium.
    b (float or int): The length of the second parallel side of the trapezium.
    h (float or int): The height of the trapezium.

    Returns:
    float: The median length of the trapezium.
    """
    return (a + b) / 2
