def amicable_numbers_sum(n):
    # Input Validation
    if not isinstance(n, int) or n < 1:
        raise ValueError("Input must be a positive integer.")

    def sum_of_divisors(num):
        divisors_sum = 0
        for i in range(1, num // 2 + 1):
            if num % i == 0:
                divisors_sum += i
        return divisors_sum

    amicable_numbers = set()

    for number in range(1, n + 1):
        if number not in amicable_numbers:
            sum1 = sum_of_divisors(number)
            if sum1 != number and sum1 <= n:  # Exclude perfect numbers and ensure sum1 is within range
                sum2 = sum_of_divisors(sum1)
                if sum2 == number and sum1 != sum2:  # Ensure they are different numbers
                    amicable_numbers.update([number, sum1])

    return sum(amicable_numbers)