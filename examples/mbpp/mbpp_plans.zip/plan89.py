def count_char_position(s: str) -> int:
    # Convert the input string to lowercase
    s = s.lower()
    
    # Initialize a counter
    counter = 0
    
    # Iterate over the string with index
    for index, char in enumerate(s):
        # Calculate the position of the character in the alphabet
        char_position = ord(char) - ord('a') + 1
        
        # Check if the character's position matches its index (1-based)
        if char_position == index + 1:
            counter += 1
    
    # Return the counter value
    return counter
