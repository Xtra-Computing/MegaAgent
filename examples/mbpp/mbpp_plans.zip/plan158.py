def sum_div(n: int) -> int:
    total_sum = 0
    for i in range(1, n):
        if n % i == 0:
            total_sum += i
    return total_sum
