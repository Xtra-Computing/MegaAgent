def eulerian_num(n, m, memo=None):
    if memo is None:
        memo = {}
    
    # Base cases
    if m >= n:
        return 0
    if n == 0 and m == 0:
        return 1
    if m == 0:
        return 1
    
    # Check if result is already computed
    if (n, m) in memo:
        return memo[(n, m)]
    
    # Recursive formula
    result = (n - m) * eulerian_num(n - 1, m - 1, memo) + (m + 1) * eulerian_num(n - 1, m, memo)
    
    # Store the result in memoization dictionary
    memo[(n, m)] = result
    return result

# Test cases
assert eulerian_num(3, 1) == 4
assert eulerian_num(4, 1) == 11
assert eulerian_num(5, 3) == 26
