def min_of_three(a: int or float, b: int or float, c: int or float) -> int or float:
    # Compare the first two numbers to find the smaller one
    min_ab = a if a < b else b
    # Compare the result with the third number to find the smallest
    return min_ab if min_ab < c else c