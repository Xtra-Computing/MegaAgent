import math

def surfacearea_sphere(r: float) -> float:
    if r <= 0:
        raise ValueError("The radius must be a positive number.")
    return 4 * math.pi * r**2
