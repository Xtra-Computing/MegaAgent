def word_len(word: str) -> bool:
    """
    Check if the length of the word is odd.

    Parameters:
    word (str): A single word whose length is to be checked.

    Returns:
    bool: Returns True if the length of the word is odd, otherwise returns False.
    """
    return len(word) % 2 != 0
