from typing import List, Tuple

def min_product_tuple(tuple_list: List[Tuple[int, int]]) -> int:
    min_product = float('inf')
    for a, b in tuple_list:
        product = a * b
        if product < min_product:
            min_product = product
    return min_product
