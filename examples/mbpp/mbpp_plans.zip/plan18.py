def bell_number(n: int) -> int:
    """
    Calculate the Bell number for a given non-negative integer n.

    :param n: A non-negative integer (0 <= n <= 100).
    :return: The Bell number for the input n.
    :raises ValueError: If n is not a non-negative integer.
    """
    if not isinstance(n, int) or n < 0:
        raise ValueError("Input must be a non-negative integer.")

    # Base case
    if n == 0:
        return 1

    # Create a 2D list to store Bell numbers
    bell = [[0 for _ in range(n+1)] for _ in range(n+1)]
    bell[0][0] = 1

    # Fill the Bell triangle
    for i in range(1, n+1):
        # Explicitly put the last value of the previous row as the first value of the current row
        bell[i][0] = bell[i-1][i-1]

        # Fill the current row
        for j in range(1, i+1):
            bell[i][j] = bell[i-1][j-1] + bell[i][j-1]

    return bell[n][0]