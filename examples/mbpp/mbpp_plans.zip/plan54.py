def merge_sorted_list(list1, list2, list3):
    # Merge the three lists
    combined_list = list1 + list2 + list3
    
    # Sort the combined list
    sorted_list = sorted(combined_list)
    
    return sorted_list
