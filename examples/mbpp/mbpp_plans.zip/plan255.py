def remove_lowercase(input_string):
    result = ''
    for char in input_string:
        if char.isupper():
            result += char
    return result
