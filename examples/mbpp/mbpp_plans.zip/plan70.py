def magic_square_test(matrix):
    # Initial Checks
    if not matrix or not all(len(row) == len(matrix) for row in matrix):
        return False
    if len(matrix) == 1:
        return True

    n = len(matrix)
    # Calculate the Magic Sum
    magic_sum = sum(matrix[0])

    # Check Rows and Columns
    for i in range(n):
        if sum(matrix[i]) != magic_sum or sum(matrix[j][i] for j in range(n)) != magic_sum:
            return False

    # Check Diagonals
    if sum(matrix[i][i] for i in range(n)) != magic_sum or sum(matrix[i][n - 1 - i] for i in range(n)) != magic_sum:
        return False

    # If all checks pass, return True
    return True
