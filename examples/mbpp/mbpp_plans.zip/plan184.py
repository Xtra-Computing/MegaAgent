def bitwise_xor(tuple1: tuple, tuple2: tuple) -> tuple:
    # Initialize an empty list to store the XOR results
    result = []
    
    # Iterate over the pairs of integers from tuple1 and tuple2
    for a, b in zip(tuple1, tuple2):
        # Compute the XOR and append to the result list
        result.append(a ^ b)
    
    # Convert the result list to a tuple and return it
    return tuple(result)