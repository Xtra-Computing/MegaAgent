from typing import List

def big_sum(arr: List[int]) -> int:
    # Step 1: Input Validation
    if not isinstance(arr, list) or len(arr) < 2:
        raise ValueError("Input must be a list with at least two integers.")
    
    # Step 2: Find Minimum and Maximum
    smallest = min(arr)
    largest = max(arr)
    
    # Step 3: Calculate Sum
    result = smallest + largest
    
    # Step 4: Return Result
    return result
