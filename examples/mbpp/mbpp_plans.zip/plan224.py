def largest_neg(lst):
    # Filter out the negative numbers
    negative_numbers = [num for num in lst if num < 0]
    
    # If there are no negative numbers, return None
    if not negative_numbers:
        return None
    
    # Return the largest negative number
    return max(negative_numbers)