def sub_list(list1: list[int], list2: list[int]) -> list[int]:
    result = []
    for a, b in zip(list1, list2):
        result.append(a - b)
    return result
