def multiply_int(a: int, b: int) -> int:
    # Handle the case where either number is zero
    if a == 0 or b == 0:
        return 0

    # Determine the sign of the result
    negative_result = (a < 0) ^ (b < 0)

    # Work with positive values for simplicity
    a, b = abs(a), abs(b)

    # Use repeated addition to calculate the product
    product = 0
    for _ in range(b):
        product += a

    # Apply the sign to the result
    return -product if negative_result else product
