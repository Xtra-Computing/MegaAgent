def dict_filter(input_dict, n):
    # Initialize an empty dictionary to store the filtered results
    filtered_dict = {}
    
    # Iterate over each key-value pair in the input dictionary
    for key, value in input_dict.items():
        # Check if the value is greater than or equal to n
        if value >= n:
            # Add the key-value pair to the filtered dictionary
            filtered_dict[key] = value
    
    # Return the filtered dictionary
    return filtered_dict
