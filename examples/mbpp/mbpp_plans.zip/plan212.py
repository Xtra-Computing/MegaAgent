def common_element(list1: list, list2: list) -> bool:
    # Input Validation
    if not isinstance(list1, list) or not isinstance(list2, list):
        raise TypeError("Both inputs must be lists.")
    
    # Empty List Check
    if not list1 or not list2:
        return None
    
    # Set Conversion
    set1 = set(list1)
    
    # Common Element Check
    for element in list2:
        if element in set1:
            return True
    
    # Return Result
    return None