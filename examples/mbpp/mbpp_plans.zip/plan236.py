def reverse_string_list(strings: list) -> list:
    # Input Validation
    if not isinstance(strings, list):
        raise TypeError("Input must be a list")
    if not all(isinstance(s, str) for s in strings):
        raise TypeError("All elements in the list must be strings")

    # Processing
    reversed_strings = [s[::-1] for s in strings]

    # Return
    return reversed_strings
