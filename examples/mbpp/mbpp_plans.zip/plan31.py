def sequence(n):
    if n <= 0:
        raise ValueError("n must be a positive integer")
    
    # Base cases
    if n == 1 or n == 2:
        return 1

    # Initialize the sequence list with base cases
    seq = [0, 1, 1]  # seq[0] is a placeholder to make the index start from 1

    # Compute the sequence values up to n
    for i in range(3, n + 1):
        seq.append(seq[seq[i - 1]] + seq[i - seq[i - 1]])

    return seq[n]