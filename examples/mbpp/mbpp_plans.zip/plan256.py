def first_Digit(number: int) -> int:
    # Convert the number to a string
    number_str = str(number)
    # Extract the first character and convert it back to an integer
    first_digit = int(number_str[0])
    # Return the first digit
    return first_digit
