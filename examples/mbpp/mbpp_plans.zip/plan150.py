import re

def text_match_two_three(input_string):
    # Use re.search to find the pattern 'ab{2,3}'
    pattern = r'ab{2,3}'
    match = re.search(pattern, input_string)
    return bool(match)