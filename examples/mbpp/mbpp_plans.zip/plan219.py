def count_bidirectional(pairs):
    seen = set()
    count = 0
    for a, b in pairs:
        if (b, a) in seen:
            count += 1
            seen.remove((b, a))  # Remove the pair to avoid double counting
        else:
            seen.add((a, b))
    return count

# The function should correctly count each unique bidirectional pair only once.
# Let's ensure the logic is correct by re-evaluating the test cases.
