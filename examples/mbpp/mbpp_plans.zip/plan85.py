def remove_elements(list1, list2):
    """
    Remove all elements from list1 that are present in list2.

    Parameters:
    list1 (list): The list from which elements are to be removed.
    list2 (list): The list containing elements to be removed from list1.

    Returns:
    list: A new list with elements from list1 that are not in list2.
    """
    set2 = set(list2)
    return [element for element in list1 if element not in set2]