from typing import Tuple

def add_nested_tuples(tuple1: Tuple[Tuple[int, ...], ...], tuple2: Tuple[Tuple[int, ...], ...]) -> Tuple[Tuple[int, ...], ...]:
    result = []
    for t1, t2 in zip(tuple1, tuple2):
        sum_tuple = tuple(a + b for a, b in zip(t1, t2))
        result.append(sum_tuple)
    return tuple(result)