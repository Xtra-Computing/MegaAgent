def sum_of_common_divisors(a, b):
    """
    Calculate the sum of common divisors of two numbers.

    Parameters:
    a (int): First positive integer.
    b (int): Second positive integer.

    Returns:
    int: Sum of common divisors of a and b.
    """
    def gcd(x, y):
        while y:
            x, y = y, x % y
        return x

    def divisors(n):
        divs = set()
        for i in range(1, int(n**0.5) + 1):
            if n % i == 0:
                divs.add(i)
                divs.add(n // i)
        return divs

    common_gcd = gcd(a, b)
    common_divs = divisors(common_gcd)
    return sum(common_divs)

# Test cases
assert sum_of_common_divisors(10, 15) == 6
assert sum_of_common_divisors(100, 150) == 93
assert sum_of_common_divisors(4, 6) == 3
