from typing import List, Tuple

def get_equal(tuples_list: List[Tuple[int, ...]]) -> bool:
    # Handle Empty List
    if not tuples_list:
        return True
    
    # Initialize Length
    reference_length = len(tuples_list[0])
    
    # Iterate and Compare
    for t in tuples_list:
        if len(t) != reference_length:
            return False
    
    # Return True if all tuples have the same length
    return True
