def square_Sum(n):
    sum = 0
    for i in range(1, n + 1):
        odd_number = 2 * i - 1
        sum += odd_number ** 2
    return sum
