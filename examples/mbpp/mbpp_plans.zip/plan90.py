def find_even_pair(numbers):
    # Initialize counter
    count = 0
    
    # Iterate through the list
    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            # Check if both numbers are even or both are odd
            if (numbers[i] % 2 == 0 and numbers[j] % 2 == 0) or (numbers[i] % 2 != 0 and numbers[j] % 2 != 0):
                count += 1
    
    # Return the result
    return count