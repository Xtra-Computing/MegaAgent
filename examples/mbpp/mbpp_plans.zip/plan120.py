def insert_element(input_list: list, element) -> list:
    # Initialize an empty list to store the new list with inserted elements
    new_list = []
    
    # Iterate over the input list
    for item in input_list:
        # Append the specified element to the new list
        new_list.append(element)
        # Append the current element from the input list to the new list
        new_list.append(item)
    
    # Return the new list
    return new_list
