def remove_dirty_chars(str1: str, str2: str) -> str:
    # Convert str2 to a set for O(1) average time complexity checks
    remove_set = set(str2)
    
    # Iterate over str1 and filter out characters present in remove_set
    result = [char for char in str1 if char not in remove_set]
    
    # Join the list into a string and return
    return ''.join(result)
