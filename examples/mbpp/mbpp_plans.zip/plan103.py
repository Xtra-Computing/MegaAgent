def replace_blank(input_string: str, replacement_char: str) -> str:
    # Input Validation
    if not replacement_char or len(replacement_char) != 1:
        raise ValueError("replacement_char must be a single character")
    
    # String Replacement
    return input_string.replace(' ', replacement_char)