def recursive_list_sum(lst: list) -> int:
    # Base Case: If the list is empty, return 0
    if not lst:
        return 0
    
    total_sum = 0
    for element in lst:
        if isinstance(element, int):
            total_sum += element
        elif isinstance(element, list):
            total_sum += recursive_list_sum(element)
    return total_sum

# Test cases
assert recursive_list_sum(([1, 2, [3,4],[5,6]]))==21
assert recursive_list_sum(([7, 10, [15,14],[19,41]]))==106
assert recursive_list_sum(([10, 20, [30,40],[50,60]]))==210
print('All test cases passed!')