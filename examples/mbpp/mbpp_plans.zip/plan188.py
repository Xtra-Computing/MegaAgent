def check_tuplex(elements: tuple, target: any) -> bool:
    # Input Validation
    if not isinstance(elements, tuple):
        raise TypeError("The first parameter must be a tuple.")
    
    # Existence Check
    return target in elements
