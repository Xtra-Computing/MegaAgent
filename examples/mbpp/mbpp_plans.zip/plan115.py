import math

def babylonian_squareroot(n):
    # Initial guess
    x = n / 2.0
    
    # Tolerance level
    tolerance = 1e-7
    
    # Iterative improvement
    while True:
        next_x = (x + n / x) / 2.0
        if abs(next_x - x) < tolerance:
            break
        x = next_x
    
    return x
