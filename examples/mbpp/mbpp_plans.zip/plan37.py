def len_log(words: list) -> int:
    max_length = 0
    for word in words:
        if len(word) > max_length:
            max_length = len(word)
    return max_length
