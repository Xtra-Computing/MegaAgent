def extract_string(strings: list, length: int) -> list:
    result = []
    for string in strings:
        if len(string) == length:
            result.append(string)
    return result
