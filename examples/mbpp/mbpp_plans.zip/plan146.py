def all_unique(elements):
    return len(elements) == len(set(elements))