from typing import List

def find_remainder(array: List[int], n: int) -> int:
    if n == 1:
        return 0
    product_mod = 1
    for num in array:
        product_mod = (product_mod * num) % n
    return product_mod
