def add_string(elements, format_string):
    return [format_string.format(element) for element in elements]