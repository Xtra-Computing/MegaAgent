def lateralsurface_cube(side_length: int) -> int:
    # Validate that side_length is a positive integer
    if side_length <= 0:
        raise ValueError("side_length must be a positive integer")
    
    # Calculate the lateral surface area using the formula: 4 * side_length^2
    lateral_surface_area = 4 * side_length ** 2
    
    return lateral_surface_area
