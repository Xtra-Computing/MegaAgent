def sum_range_list(numbers: list, start_index: int, end_index: int) -> int:
    # Calculate the sum of the elements in the specified range
    return sum(numbers[start_index:end_index + 1])
