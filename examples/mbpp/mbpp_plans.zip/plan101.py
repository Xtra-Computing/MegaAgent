def all_Bits_Set_In_The_Given_Range(number, start, end):
    # Shift the number right by (start - 1) to align the range with the least significant bits
    shifted_number = number >> (start - 1)
    
    # Create a mask with bits set in the range from start to end
    mask = (1 << (end - start + 1)) - 1
    
    # Check if all bits in the range are unset (0)
    return (shifted_number & mask) == 0

# Unit test cases
assert all_Bits_Set_In_The_Given_Range(4, 1, 2) == True
assert all_Bits_Set_In_The_Given_Range(17, 2, 4) == True
assert all_Bits_Set_In_The_Given_Range(39, 4, 6) == False
