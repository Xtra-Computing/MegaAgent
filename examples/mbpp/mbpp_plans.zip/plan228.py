from typing import List

def cube_nums(numbers: List[int]) -> List[int]:
    # Input Validation
    if not isinstance(numbers, list) or not all(isinstance(x, int) for x in numbers):
        raise ValueError("Input must be a list of integers.")
    
    # Cubing Process
    cubed_numbers = [x ** 3 for x in numbers]
    
    # Return Result
    return cubed_numbers
