def parabola_directrix(a: int, b: int, c: int) -> int:
    """
    Calculate the directrix of a parabola given its coefficients a, b, and c.

    Parameters:
    a (int): The coefficient of x^2.
    b (int): The coefficient of x.
    c (int): The constant term.

    Returns:
    int: The y-coordinate of the directrix of the parabola.
    """
    # Calculate the directrix using the formula
    directrix = c - (b**2 + 1) / (4 * a)
    # Return the directrix as an integer
    return int(directrix)
