def decimal_to_binary(n: int) -> str:
    # Edge Case Handling
    if n == 0:
        return '0'
    
    # Conversion
    binary_representation = bin(n)[2:]
    
    # Return
    return binary_representation
