def get_Char(s: str) -> str:
    # Initialize the sum of ASCII values
    ascii_sum = 0
    
    # Iterate over each character in the string
    for char in s:
        ascii_sum += ord(char) - ord('a') + 1
    
    # Calculate the result of the sum modulo 26
    result = ascii_sum % 26
    
    # Convert the result to a character by adding it to the ASCII value of 'a'
    result_char = chr(result + ord('a') - 1)
    
    return result_char

# Unit test cases
assert get_Char("abc") == "f"
assert get_Char("gfg") == "t"
assert get_Char("ab") == "c"
