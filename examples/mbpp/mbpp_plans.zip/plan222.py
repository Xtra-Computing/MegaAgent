def surfacearea_cube(side_length):
    return 6 * (side_length ** 2)