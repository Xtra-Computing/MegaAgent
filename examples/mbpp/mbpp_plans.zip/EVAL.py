import pandas as pd
import os
import shutil
import subprocess
from datasets import load_dataset
import sys

dataset_sanitized = load_dataset("google-research-datasets/mbpp", "sanitized")

sum = 0
passed = 0
# 针对每一行进行处理
for index, row in enumerate(dataset_sanitized['test']):
    sum += 1
    # 运行 main.py
    while True:
            with open(f"plan{index}.py", 'r') as f:
                program_content = f.read()
            try:
                for case in row['test_list']:
                    with subprocess.Popen([sys.executable, '-c', program_content+'\n'+case], 
                                        stdout=subprocess.PIPE, 
                                        stderr=subprocess.PIPE) as proc:
                        try:
                            proc.wait(timeout=5)  # 5 second timeout
                            if proc.returncode != 0:
                                raise AssertionError("Test failed")
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            raise AssertionError("Test timed out")
                passed += 1
                break
            except AssertionError:
                print(f"{index},", end="")
                break
            
print(f"Passed {passed}/{sum} test cases")
