def max_length(list_of_lists: list) -> tuple:
    max_len = 0
    max_list = []
    for sublist in list_of_lists:
        if len(sublist) > max_len:
            max_len = len(sublist)
            max_list = sublist
    return (max_len, max_list)