from typing import List, Any

def replace_list(list1: List[Any], list2: List[Any]) -> List[Any]:
    # Ensure list1 has at least one element
    if not list1:
        raise ValueError("list1 must have at least one element")
    
    # Remove the last element of list1
    modified_list1 = list1[:-1]
    
    # Append all elements of list2
    modified_list1.extend(list2)
    
    return modified_list1
