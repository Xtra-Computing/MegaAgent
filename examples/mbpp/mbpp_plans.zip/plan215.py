import re

def text_match_one(input_string: str) -> bool:
    # Compile the regular expression pattern 'ab+'
    pattern = re.compile(r'ab+')
    
    # Use re.search() to find the pattern in input_string
    match = pattern.search(input_string)
    
    # Return True if the pattern is found, otherwise return False
    return bool(match)