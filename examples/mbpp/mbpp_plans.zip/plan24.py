def is_samepatterns(colors, patterns):
    # Check if the lengths of colors and patterns are the same
    if len(colors) != len(patterns):
        return False

    # Create a dictionary to map elements from patterns to colors
    pattern_to_color = {}

    # Iterate through the patterns list
    for pattern, color in zip(patterns, colors):
        if pattern in pattern_to_color:
            # If the pattern is already in the dictionary, check for consistency
            if pattern_to_color[pattern] != color:
                return False
        else:
            # Add the mapping from pattern to color
            pattern_to_color[pattern] = color

    # If the loop completes without inconsistencies, return True
    return True
