def trim_tuple(tuple_list: list, k: int) -> list:
    """
    Trims each tuple in the given list of tuples by removing 'k' elements from both the start and the end.
    Returns a new list of trimmed tuples.

    Parameters:
    tuple_list (list): A list of tuples to be trimmed.
    k (int): The number of elements to remove from both the start and the end of each tuple.

    Returns:
    list: A list of tuples after trimming.
    """
    trimmed_list = []
    for t in tuple_list:
        trimmed_list.append(t[k:-k] if k < len(t) else ())
    return trimmed_list