def check_element(lst, element):
    """
    Check if all elements in the list are equal to the given element.

    Parameters:
    lst (list): The list of elements to check.
    element: The element to compare against.

    Returns:
    bool: True if all elements in the list are equal to the given element, False otherwise.
    """
    for item in lst:
        if item != element:
            return False
    return True
