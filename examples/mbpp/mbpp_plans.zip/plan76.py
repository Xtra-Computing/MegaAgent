import math

def zero_count(arr):
    zeroes = arr.count(0)
    non_zeroes = len(arr) - zeroes
    if non_zeroes == 0:
        return float('inf')
    return zeroes / non_zeroes
