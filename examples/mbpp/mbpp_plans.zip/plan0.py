def remove_Occ(string, char):
    # Find the first occurrence of the character
    first_occ = string.find(char)
    
    # Find the last occurrence of the character
    last_occ = string.rfind(char)
    
    # If the first and last occurrences are the same, remove the character at that position
    if first_occ == last_occ:
        return string[:first_occ] + string[first_occ+1:]
    
    # Remove the character at both the first and last occurrence positions
    return string[:first_occ] + string[first_occ+1:last_occ] + string[last_occ+1:]