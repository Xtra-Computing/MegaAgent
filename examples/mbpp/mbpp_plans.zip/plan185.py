def extract_freq(tuples_list):
    unique_tuples = set()
    for a, b in tuples_list:
        # Add the tuple in a sorted order to handle unordered pairs
        unique_tuples.add(tuple(sorted((a, b))))
    return len(unique_tuples)