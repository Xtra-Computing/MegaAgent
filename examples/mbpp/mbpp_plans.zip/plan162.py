import math
from math import comb

def count_binary_seq(n: int) -> float:
    total_sequences = 0
    for k in range(n + 1):
        total_sequences += comb(n, k) ** 2
    return float(total_sequences)