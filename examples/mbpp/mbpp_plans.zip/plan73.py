def tup_string(input_tuple):
    # Check if the tuple is empty
    if not input_tuple:
        return ""
    # Use join to concatenate tuple elements
    return ''.join(input_tuple)
