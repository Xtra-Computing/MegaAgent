def remove_odd(numbers: list) -> list:
    return [num for num in numbers if num % 2 == 0]