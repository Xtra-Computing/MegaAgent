from typing import List, Tuple

def subject_marks(subjects: List[Tuple[str, int]]) -> List[Tuple[str, int]]:
    # Sort the list of tuples based on the second element (marks)
    return sorted(subjects, key=lambda subject: subject[1])
