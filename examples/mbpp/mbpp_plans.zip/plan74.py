def sum_negativenum(numbers):
    """
    Calculate the sum of negative numbers in a list.

    Parameters:
    numbers (list): A list of numbers.

    Returns:
    int: The sum of negative numbers in the list.
    """
    negative_sum = 0
    for num in numbers:
        if num < 0:
            negative_sum += num
    return negative_sum
