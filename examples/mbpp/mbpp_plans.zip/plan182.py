def median_numbers(a: float, b: float, c: float) -> float:
    """
    Calculate the median of three numbers.

    Parameters:
    - a (float): The first number.
    - b (float): The second number.
    - c (float): The third number.

    Returns:
    - float: The median of the three numbers.
    """
    numbers = [a, b, c]
    numbers.sort()
    return numbers[1]