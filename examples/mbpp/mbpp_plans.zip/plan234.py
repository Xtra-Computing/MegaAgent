import re

def text_match_wordz(input_string: str) -> bool:
    # Define the regular expression pattern to match words containing 'z'
    pattern = r'\b\w*z\w*\b'
    
    # Use re.search to find if any word in the string contains 'z'
    if re.search(pattern, input_string):
        return True
    else:
        return False
