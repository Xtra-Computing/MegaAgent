def Extract(list_of_lists: list) -> list:
    result = []
    for sublist in list_of_lists:
        result.append(sublist[0])
    return result
