def concatenate_tuple(input_tuple: tuple) -> str:
    # Step 1: Input Validation
    if not isinstance(input_tuple, tuple):
        raise TypeError("Input must be a tuple")
    
    # Step 2: Conversion to String and Step 3: Concatenation
    concatenated_string = '-'.join(str(element) for element in input_tuple)
    
    # Step 4: Return
    return concatenated_string

# Example test cases
assert concatenate_tuple(("ID", "is", 4, "UTS")) == 'ID-is-4-UTS'
assert concatenate_tuple(("QWE", "is", 4, "RTY")) == 'QWE-is-4-RTY'
assert concatenate_tuple(("ZEN", "is", 4, "OP")) == 'ZEN-is-4-OP'