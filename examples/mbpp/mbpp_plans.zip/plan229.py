def cal_sum(n: int) -> int:
    # Base cases
    if n == 0:
        return 3
    elif n == 1:
        return 3 + 0
    elif n == 2:
        return 3 + 0 + 2

    # Initial Perrin numbers
    p0, p1, p2 = 3, 0, 2
    sum_perrin = p0 + p1 + p2

    # Calculate the sum of the first n Perrin numbers
    for i in range(3, n + 1):
        p_next = p0 + p1
        sum_perrin += p_next
        p0, p1, p2 = p1, p2, p_next

    return sum_perrin

# Test cases
assert cal_sum(9) == 49
assert cal_sum(10) == 66
assert cal_sum(11) == 88

print("All test cases passed.")