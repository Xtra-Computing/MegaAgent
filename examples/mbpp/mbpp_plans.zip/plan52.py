def count(boolean_list: list) -> int:
    # Initialize a counter to zero
    counter = 0
    # Iterate through each element in the list
    for element in boolean_list:
        # Check if the element is True
        if element is True:
            # Increment the counter by one
            counter += 1
    # Return the counter value
    return counter