def find_length(binary_string):
    # Edge case: if the string is empty, return 0
    if not binary_string:
        return 0

    # Transform the binary string into an array of +1 and -1
    transformed = [1 if char == '0' else -1 for char in binary_string]

    # Initialize variables for Kadane's algorithm
    max_diff = 0
    current_sum = 0

    # Iterate through the transformed array
    for value in transformed:
        current_sum += value
        if current_sum < 0:
            current_sum = 0
        max_diff = max(max_diff, current_sum)

    return max_diff