def max_sum(arr):
    n = len(arr)
    if n == 0:
        return 0
    if n == 1:
        return arr[0]

    # Initialize the increasing and decreasing subsequence arrays
    inc = [0] * n
    dec = [0] * n

    # Fill the increasing subsequence array
    for i in range(n):
        inc[i] = arr[i]
        for j in range(i):
            if arr[j] < arr[i] and inc[i] < inc[j] + arr[i]:
                inc[i] = inc[j] + arr[i]

    # Fill the decreasing subsequence array
    for i in range(n-1, -1, -1):
        dec[i] = arr[i]
        for j in range(n-1, i, -1):
            if arr[j] < arr[i] and dec[i] < dec[j] + arr[i]:
                dec[i] = dec[j] + arr[i]

    # Calculate the maximum sum of bitonic subsequence
    max_sum = 0
    for i in range(n):
        max_sum = max(max_sum, inc[i] + dec[i] - arr[i])

    return max_sum
