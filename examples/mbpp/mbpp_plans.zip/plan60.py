def list_to_float(input_list: list[tuple[str, ...]]) -> list[tuple[float, ...]]:
    result = []
    for item in input_list:
        converted_tuple = tuple(float(x) for x in item)
        result.append(converted_tuple)
    return result
