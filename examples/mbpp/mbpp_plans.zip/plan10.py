def opposite_Signs(x: int, y: int) -> bool:
    """
    Determine if two integers have opposite signs.

    Parameters:
    x (int): First integer.
    y (int): Second integer.

    Returns:
    bool: True if x and y have opposite signs, False otherwise.
    """
    return (x ^ y) < 0
