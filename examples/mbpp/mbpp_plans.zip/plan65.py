import cmath

def angle_complex(z):
    return cmath.phase(z)