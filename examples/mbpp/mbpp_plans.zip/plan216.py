def last_Digit(number: int) -> int:
    return number % 10
