import math

def next_Perfect_Square(n: int) -> int:
    # Calculate the integer part of the square root of n
    root = int(math.sqrt(n))
    
    # Check if the square of this integer is less than or equal to n
    if root * root <= n:
        root += 1
    
    # Return the square of the resulting integer
    return root * root
