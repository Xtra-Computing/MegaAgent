def is_sublist(main_list: list, sub_list: list) -> bool:
    # Edge Case Handling
    if not sub_list:
        return True
    if not main_list:
        return False

    # Iterate Over Main List
    sub_len = len(sub_list)
    for i in range(len(main_list) - sub_len + 1):
        # Sublist Matching
        if main_list[i:i + sub_len] == sub_list:
            return True

    # Return Result
    return False
