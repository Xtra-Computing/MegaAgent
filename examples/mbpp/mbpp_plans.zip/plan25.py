def find_tuples(tuples_list: list[tuple[int, ...]], k: int) -> list[tuple[int, ...]]:
    """
    Find tuples with all elements divisible by a given integer `k`.

    Parameters:
    tuples_list (list of tuple of int): A list of tuples, each containing integers.
    k (int): The integer divisor.

    Returns:
    list of tuple of int: A list of tuples where all elements are divisible by `k`.

    Raises:
    ValueError: If `k` is not a positive integer.
    """
    if k <= 0:
        raise ValueError("k must be a positive integer")

    result = []
    for t in tuples_list:
        if all(element % k == 0 for element in t):
            result.append(t)
    return result
