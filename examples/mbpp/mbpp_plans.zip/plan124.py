def count_Primes_nums(n: int) -> int:
    """
    Calculate the number of prime numbers less than a given non-negative integer n.

    Parameters:
    n (int): A non-negative integer representing the upper limit (exclusive) for counting prime numbers.

    Returns:
    int: The number of prime numbers less than n.
    """
    if n <= 1:
        return 0

    # Initialize a list to track prime numbers
    is_prime = [True] * n
    is_prime[0] = is_prime[1] = False

    # Implement Sieve of Eratosthenes
    for i in range(2, int(n**0.5) + 1):
        if is_prime[i]:
            for j in range(i * i, n, i):
                is_prime[j] = False

    # Count the number of prime numbers
    return sum(is_prime)