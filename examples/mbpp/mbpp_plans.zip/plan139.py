def substract_elements(tuple1: tuple, tuple2: tuple) -> tuple:
    if len(tuple1) != len(tuple2):
        raise ValueError("Both tuples must be of the same length.")
    return tuple(a - b for a, b in zip(tuple1, tuple2))
