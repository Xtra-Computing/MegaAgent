def find_solution(a: int, b: int, n: int) -> tuple:
    def extended_gcd(aa, bb):
        if bb == 0:
            return aa, 1, 0
        g, x1, y1 = extended_gcd(bb, aa % bb)
        x = y1
        y = x1 - (aa // bb) * y1
        return g, x, y

    g, x, y = extended_gcd(a, b)

    if n % g != 0:
        return None

    x *= n // g
    y *= n // g

    return x, y
