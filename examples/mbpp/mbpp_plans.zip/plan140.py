import math

def even_binomial_Coeff_Sum(n):
    # Initialize sum
    sum_even_indices = 0
    
    # Iterate over even indices
    for k in range(0, n + 1, 2):
        # Calculate binomial coefficient C(n, k)
        binom_coeff = math.comb(n, k)
        # Add to sum
        sum_even_indices += binom_coeff
    
    return sum_even_indices
