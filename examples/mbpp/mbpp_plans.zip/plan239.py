def remove_uppercase(input_string: str) -> str:
    result = []
    i = 0
    while i < len(input_string):
        if input_string[i].isupper():
            # Skip the entire uppercase substring
            while i < len(input_string) and input_string[i].isupper():
                i += 1
        else:
            # Append non-uppercase character to result
            result.append(input_string[i])
            i += 1
    return ''.join(result)
