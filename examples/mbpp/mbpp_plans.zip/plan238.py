def rectangle_area(width: float, height: float) -> float:
    # Input Validation
    if width < 0 or height < 0:
        raise ValueError("Width and height must be non-negative.")
    
    # Calculate Area
    area = width * height
    
    # Return Result
    return area
