def is_Sum_Of_Powers_Of_Two(n):
    # Check if the number can be represented as a sum of distinct non-zero powers of 2
    # This is equivalent to checking if the number has no repeated '1's in its binary representation
    if n <= 0:
        return False
    
    # Check if n has only one '1' in its binary representation
    return (n & (n - 1)) == 0
