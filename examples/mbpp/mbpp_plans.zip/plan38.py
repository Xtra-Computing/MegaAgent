def find_substring(strings: list, substring: str) -> bool:
    # Initial Checks
    if not strings or not substring:
        return False

    # Iterate through the List
    for string in strings:
        if substring in string:
            return True

    # Return False if substring is not found
    return False
