def string_to_list(input_string: str) -> list:
    return input_string.split()