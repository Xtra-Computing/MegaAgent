def count_first_elements(input_tuple: tuple) -> int:
    count = 0
    for element in input_tuple:
        if isinstance(element, tuple):
            break
        count += 1
    return count

# Test cases
print(count_first_elements((1, 5, 7, (4, 6), 10)))  # Expected output: 3
print(count_first_elements((2, 9, (5, 7), 11)))    # Expected output: 2
print(count_first_elements((11, 15, 5, 8, (2, 3), 8)))  # Expected output: 4
