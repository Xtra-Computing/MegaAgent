def volume_cube(side_length: int) -> int:
    return side_length ** 3
