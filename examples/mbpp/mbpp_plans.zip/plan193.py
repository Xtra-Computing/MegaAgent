def min_val(lst: list) -> int:
    # Filter out non-integer elements
    integers = [x for x in lst if isinstance(x, int)]
    # Find and return the minimum integer
    return min(integers)