def sum_even_and_even_index(numbers: list) -> int:
    total_sum = 0
    for index, element in enumerate(numbers):
        if index % 2 == 0 and element % 2 == 0:
            total_sum += element
    return total_sum
