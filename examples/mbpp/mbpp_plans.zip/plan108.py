def check_occurences(tuples_list):
    occurrences = {}
    for tup in tuples_list:
        sorted_tup = tuple(sorted(tup))
        if sorted_tup in occurrences:
            occurrences[sorted_tup] += 1
        else:
            occurrences[sorted_tup] = 1
    return occurrences
