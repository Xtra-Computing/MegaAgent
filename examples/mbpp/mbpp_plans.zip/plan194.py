def snake_to_camel(snake_str: str) -> str:
    # Split the string by underscores
    words = snake_str.split('_')
    # Capitalize the first letter of each word and join them
    camel_case_str = ''.join(word.capitalize() for word in words)
    return camel_case_str
