def get_total_number_of_sequences(m, n):
    # Input validation
    if not (1 <= m <= 1000 and 1 <= n <= 1000):
        raise ValueError("m and n must be positive integers within the range 1 to 1000.")

    # Memoization dictionary
    memo = {}

    def count_sequences(current, remaining_length):
        # Base case: if no more elements to add, return 1 sequence found
        if remaining_length == 0:
            return 1

        # Check memoization
        if (current, remaining_length) in memo:
            return memo[(current, remaining_length)]

        total_sequences = 0

        # Iterate over possible next elements
        for next_element in range(current * 2, m + 1):
            total_sequences += count_sequences(next_element, remaining_length - 1)

        # Store result in memoization dictionary
        memo[(current, remaining_length)] = total_sequences
        return total_sequences

    # Start counting sequences from each possible starting element
    total = 0
    for start in range(1, m + 1):
        total += count_sequences(start, n - 1)

    return total