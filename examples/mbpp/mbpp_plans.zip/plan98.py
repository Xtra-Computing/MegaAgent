def count_Set_Bits(n: int) -> int:
    """
    Count the number of set bits (1s) in the binary representation of a non-negative integer.

    Parameters:
    n (int): A non-negative integer.

    Returns:
    int: The number of set bits in the binary representation of the input number.
    """
    # Convert the number to binary and count the '1's
    return bin(n).count('1')
