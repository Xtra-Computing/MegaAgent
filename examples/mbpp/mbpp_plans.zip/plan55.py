def odd_Equivalent(binary_string, rotations):
    # Input Validation
    if not all(c in '01' for c in binary_string):
        raise ValueError("The binary string must consist only of '0's and '1's.")
    if not isinstance(rotations, int) or rotations < 1:
        raise ValueError("The number of rotations must be a positive integer.")

    odd_count = 0
    length = len(binary_string)

    # Perform rotations and check for odd numbers
    for i in range(rotations):
        # Rotate the string
        rotated_string = binary_string[i % length:] + binary_string[:i % length]
        # Convert to decimal
        decimal_value = int(rotated_string, 2)
        # Check if the number is odd
        if decimal_value % 2 == 1:
            odd_count += 1

    return odd_count
