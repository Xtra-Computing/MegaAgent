def check_Consecutive(numbers):
    # Edge Case Handling
    if len(numbers) < 2:
        return False
    
    # Sorting
    sorted_numbers = sorted(numbers)
    
    # Consecutive Check
    for i in range(1, len(sorted_numbers)):
        if sorted_numbers[i] != sorted_numbers[i - 1] + 1:
            return False
    
    return True
