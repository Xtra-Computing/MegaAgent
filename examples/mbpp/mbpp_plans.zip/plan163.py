def dict_depth(d: dict) -> int:
    # Base Case: If the dictionary is empty, return 1
    if not d:
        return 1

    # Recursive Case: Initialize max_depth to 1
    max_depth = 1

    # Iterate over the values of the dictionary
    for value in d.values():
        # Check if the value is a dictionary
        if isinstance(value, dict):
            # Recursively calculate the depth of the sub-dictionary
            sub_depth = dict_depth(value)
            # Update max_depth if necessary
            max_depth = max(max_depth, sub_depth + 1)

    return max_depth
