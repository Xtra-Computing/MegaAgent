def lps(input_string: str) -> int:
    n = len(input_string)
    if n == 0:
        return 0

    # Create a table to store results of subproblems
    dp = [[0] * n for _ in range(n)]

    # Strings of length 1 are palindrome of length 1
    for i in range(n):
        dp[i][i] = 1

    # Build the table. The outer loop is for substrings of length 2 to n
    for cl in range(2, n + 1):
        for i in range(n - cl + 1):
            j = i + cl - 1
            if input_string[i] == input_string[j]:
                dp[i][j] = dp[i + 1][j - 1] + 2
            else:
                dp[i][j] = max(dp[i][j - 1], dp[i + 1][j])

    # Length of longest palindromic subseq
    return dp[0][n - 1]