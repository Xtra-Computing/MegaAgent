def are_equivalent(a, b):
    """
    Determine if the sum of the divisors of two integers are the same.

    Parameters:
    a (int): First integer.
    b (int): Second integer.

    Returns:
    bool: True if the sum of the divisors of the two integers are the same, False otherwise.
    """
    def sum_of_divisors(n):
        if n <= 0:
            return 0
        total = 0
        for i in range(1, n):  # Only consider proper divisors
            if n % i == 0:
                total += i
        return total

    return sum_of_divisors(a) == sum_of_divisors(b)

# Test cases
assert are_equivalent(36, 57) == False
assert are_equivalent(2, 4) == False
assert are_equivalent(23, 47) == True
