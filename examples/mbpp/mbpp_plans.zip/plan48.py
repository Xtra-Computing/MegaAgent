def kth_element(array, k):
    # Since k is 1-based, we need to access the (k-1)th index in 0-based indexing
    return array[k - 1]