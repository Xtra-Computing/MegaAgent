def frequency(lst, num):
    # Initialize a counter to zero
    count = 0
    
    # Iterate over each element in the list
    for element in lst:
        # Check if the element is equal to num
        if element == num:
            # Increment the counter
            count += 1
    
    # Return the counter value
    return count
