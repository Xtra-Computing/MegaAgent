from itertools import combinations_with_replacement

def combinations_colors(elements, n):
    if not elements or n <= 0:
        return []
    return list(combinations_with_replacement(elements, n))