def next_smallest_palindrome(n):
    # Helper function to check if a number is a palindrome
    def is_palindrome(x):
        return str(x) == str(x)[::-1]

    # If the number is a single-digit, return n + 1
    if 0 <= n < 9:
        return n + 1

    # Start checking from the next number
    current = n + 1
    while True:
        if is_palindrome(current):
            return current
        current += 1
