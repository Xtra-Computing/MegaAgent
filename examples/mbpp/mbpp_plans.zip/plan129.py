def split_two_parts(input_list, L):
    # Validate that L is less than or equal to the length of input_list
    if L > len(input_list):
        raise ValueError("L must be less than or equal to the length of input_list")
    
    # Use list slicing to create the first list with the first L elements
    first_part = input_list[:L]
    
    # Use list slicing to create the second list with the remaining elements
    second_part = input_list[L:]
    
    # Return a tuple containing the two lists
    return (first_part, second_part)

# Test cases
print(split_two_parts([1,1,2,3,4,4,5,1],3))  # Expected: ([1, 1, 2], [3, 4, 4, 5, 1])
print(split_two_parts(['a', 'b', 'c', 'd'],2))  # Expected: (['a', 'b'], ['c', 'd'])
print(split_two_parts(['p', 'y', 't', 'h', 'o', 'n'],4))  # Expected: (['p', 'y', 't', 'h'], ['o', 'n'])