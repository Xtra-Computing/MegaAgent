def otherside_rightangle(a, b):
    # Calculate the third side using the Pythagorean theorem
    return (a**2 + b**2)**0.5
