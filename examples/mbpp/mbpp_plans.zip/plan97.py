def is_majority(arr: list, n: int, element: int) -> bool:
    if n == 0:
        return False

    # Binary search for the first occurrence of element
    first_occurrence = binary_search_first_occurrence(arr, element)
    if first_occurrence == -1:
        return False

    # Check if element is the majority
    if first_occurrence + n // 2 < n and arr[first_occurrence + n // 2] == element:
        return True
    else:
        return False


def binary_search_first_occurrence(arr: list, element: int) -> int:
    left = 0
    right = len(arr) - 1
    result = -1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == element:
            result = mid
            right = mid - 1  # Look on the left side for the first occurrence
        elif arr[mid] < element:
            left = mid + 1
        else:
            right = mid - 1
    return result
