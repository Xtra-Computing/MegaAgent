def dif_Square(n: int) -> bool:
    # Check if n is of the form 4k + 2
    if n % 4 == 2:
        return False
    return True
