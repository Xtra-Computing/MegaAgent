def snake_to_camel(snake_str: str) -> str:
    # Split the input string by underscores
    words = snake_str.split('_')
    
    # Capitalize the first letter of each word
    capitalized_words = [word.capitalize() for word in words]
    
    # Join the capitalized words into a single string
    camel_case_str = ''.join(capitalized_words)
    
    return camel_case_str
