def flatten_list(nested_list):
    """
    Flattens a nested list structure into a single list.

    Parameters:
    nested_list (list): A list that may contain nested lists.

    Returns:
    list: A single, flat list containing all the elements from the nested lists in the same order.
    """
    flat_list = []
    for element in nested_list:
        if isinstance(element, list):
            flat_list.extend(flatten_list(element))
        else:
            flat_list.append(element)
    return flat_list
