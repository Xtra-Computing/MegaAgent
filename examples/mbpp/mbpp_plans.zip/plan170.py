def string_to_tuple(input_string):
    return tuple(input_string)