def validate(integer):
    # Convert the integer to a string to iterate over each digit
    str_integer = str(abs(integer))  # Use abs to handle negative numbers
    
    # Create a dictionary to count the frequency of each digit
    digit_count = {}
    
    # Count the frequency of each digit
    for digit in str_integer:
        if digit in digit_count:
            digit_count[digit] += 1
        else:
            digit_count[digit] = 1
    
    # Check if the frequency of each digit is less than or equal to the digit itself
    for digit, count in digit_count.items():
        if count > int(digit):
            return False
    
    return True
