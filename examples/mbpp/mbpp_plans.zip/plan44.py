def frequency_lists(list_of_lists):
    from collections import Counter
    # Flatten the list of lists
    flattened_list = [item for sublist in list_of_lists for item in sublist]
    # Calculate frequencies
    frequency = Counter(flattened_list)
    # Return as a dictionary
    return dict(frequency)
