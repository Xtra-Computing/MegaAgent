def smallest_num(numbers: list) -> int:
    # Use Python's built-in min function to find the smallest number
    return min(numbers)