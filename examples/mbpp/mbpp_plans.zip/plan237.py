def Find_Min(list_of_sublists):
    # Initialize with the first sublist
    min_sublist = list_of_sublists[0]
    
    # Iterate through each sublist
    for sublist in list_of_sublists:
        if len(sublist) < len(min_sublist):
            min_sublist = sublist
    
    return min_sublist