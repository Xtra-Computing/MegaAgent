def freq_count(elements):
    """
    Calculate the frequency of each element in the list.

    Parameters:
    elements (list): A list of hashable elements.

    Returns:
    dict: A dictionary with elements as keys and their frequencies as values.
    """
    frequency_dict = {}
    for element in elements:
        if element in frequency_dict:
            frequency_dict[element] += 1
        else:
            frequency_dict[element] = 1
    return frequency_dict
