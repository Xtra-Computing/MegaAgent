def neg_nos(numbers: list) -> list:
    return [num for num in numbers if num < 0]