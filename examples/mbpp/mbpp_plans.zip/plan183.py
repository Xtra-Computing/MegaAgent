def sum_of_digits(lst):
    total_sum = 0
    for item in lst:
        if isinstance(item, int):
            num = abs(item)
            while num > 0:
                total_sum += num % 10
                num //= 10
    return total_sum
