def count_occurance(input_string):
    """
    Count the number of occurrences of the substring 'std' in the given input string.

    Parameters:
    input_string (str): The string in which to count occurrences of 'std'.

    Returns:
    int: The number of times 'std' appears in the input string.
    """
    return input_string.count('std')
