def upper_ctr(input_string: str) -> int:
    return sum(1 for char in input_string if char.isupper())

# Test cases
assert upper_ctr('PYthon') == 2
assert upper_ctr('BigData') == 2
assert upper_ctr('program') == 0
