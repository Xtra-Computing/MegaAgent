from typing import List

def sort_matrix(matrix: List[List[int]]) -> List[List[int]]:
    """
    Sorts a given matrix in ascending order according to the sum of its rows.

    Parameters:
    matrix (List[List[int]]): A list of lists where each sublist represents a row of the matrix.

    Returns:
    List[List[int]]: A new matrix sorted in ascending order based on the sum of each row.

    Raises:
    ValueError: If the input is not a list of lists or if any element is not an integer.

    Example:
    >>> sort_matrix([[1, 2, 3], [2, 4, 5], [1, 1, 1]])
    [[1, 1, 1], [1, 2, 3], [2, 4, 5]]

    >>> sort_matrix([[1, 2, 3], [-2, 4, -5], [1, -1, 1]])
    [[-2, 4, -5], [1, -1, 1], [1, 2, 3]]

    >>> sort_matrix([[5,8,9],[6,4,3],[2,1,4]])
    [[2, 1, 4], [6, 4, 3], [5, 8, 9]]
    """
    # Input Validation
    if not all(isinstance(row, list) for row in matrix):
        raise ValueError("Input must be a list of lists")
    if not all(all(isinstance(item, int) for item in row) for row in matrix):
        raise ValueError("All elements must be integers")

    # Calculate Row Sums and Sort the Matrix
    sorted_matrix = sorted(matrix, key=sum)

    return sorted_matrix
