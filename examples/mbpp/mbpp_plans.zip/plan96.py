def check_type(input_tuple):
    # Check if the tuple is empty
    if not input_tuple:
        return True
    
    # Get the type of the first element
    first_type = type(input_tuple[0])
    
    # Iterate over the tuple and compare types
    for element in input_tuple:
        if type(element) != first_type:
            return False
    
    return True
