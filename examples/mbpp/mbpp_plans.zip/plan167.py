def colon_tuplex(input_tuple: tuple, index: int, value: any) -> tuple:
    # Validate Input
    if not (0 <= index < len(input_tuple)):
        raise ValueError("Index is out of bounds.")
    if not isinstance(input_tuple[index], list):
        raise ValueError("Element at the specified index is not a list.")

    # Copy Tuple
    temp_list = list(input_tuple)

    # Modify List
    temp_list[index] = temp_list[index] + [value]

    # Reconstruct Tuple
    result_tuple = tuple(temp_list)

    # Return Result
    return result_tuple
