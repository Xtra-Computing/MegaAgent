def change_date_format(date_str):
    # Split the input date string by '-'
    year, month, day = date_str.split('-')
    # Rearrange to 'dd-mm-yyyy' format
    return f"{day}-{month}-{year}"
