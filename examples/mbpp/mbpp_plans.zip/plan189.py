def find_Parity(number):
    return number % 2 == 1