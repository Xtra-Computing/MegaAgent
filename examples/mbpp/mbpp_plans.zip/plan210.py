def and_tuples(tuple1, tuple2):
    # Initialize an empty list to store the results
    result = []
    
    # Iterate over the elements of the input tuples
    for a, b in zip(tuple1, tuple2):
        # Perform a bitwise AND operation and append the result
        result.append(a & b)
    
    # Convert the results list to a tuple and return it
    return tuple(result)