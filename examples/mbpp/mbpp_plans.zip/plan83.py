def max_Abs_Diff(numbers):
    if not numbers or len(numbers) < 2:
        raise ValueError("Input must be a tuple with at least two elements.")
    
    min_val = float('inf')
    max_val = float('-inf')
    
    for number in numbers:
        if number < min_val:
            min_val = number
        if number > max_val:
            max_val = number
    
    return max_val - min_val
