def Find_Min_Length(list_of_lists):
    # Initialize min_length to a very large number
    min_length = float('inf')
    
    # Iterate over each sublist in list_of_lists
    for sublist in list_of_lists:
        # Calculate the length of the current sublist
        current_length = len(sublist)
        
        # Update min_length if the current sublist is shorter
        if current_length < min_length:
            min_length = current_length
    
    # Return the smallest length found
    return min_length
