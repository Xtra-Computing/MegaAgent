def empty_dit(lst):
    # Check if the input is a dictionary
    if isinstance(lst, dict):
        return len(lst) == 0
    
    # Check if the input is a list
    if isinstance(lst, list):
        for item in lst:
            # Check if the item is a dictionary and if it is not empty
            if isinstance(item, dict) and len(item) != 0:
                return False
            # If the item is not a dictionary, return False
            elif not isinstance(item, dict):
                return False
        return True
    
    # If the input is neither a dictionary nor a list, return False
    return False

# Unit tests
assert empty_dit([{},{},{}]) == True
assert empty_dit([{1,2},{},{}]) == False
assert empty_dit({}) == True
