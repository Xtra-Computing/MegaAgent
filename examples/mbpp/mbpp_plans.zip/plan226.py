from typing import Tuple

def index_multiplication(tuple1: Tuple[Tuple[int, int], ...], tuple2: Tuple[Tuple[int, int], ...]) -> Tuple[Tuple[int, int], ...]:
    result = []
    for a, b in zip(tuple1, tuple2):
        result.append((a[0] * b[0], a[1] * b[1]))
    return tuple(result)

# Test cases
if __name__ == "__main__":
    print(index_multiplication(((1, 3), (4, 5), (2, 9), (1, 10)), ((6, 7), (3, 9), (1, 1), (7, 3))))
    print(index_multiplication(((2, 4), (5, 6), (3, 10), (2, 11)), ((7, 8), (4, 10), (2, 2), (8, 4))))
    print(index_multiplication(((3, 5), (6, 7), (4, 11), (3, 12)), ((8, 9), (5, 11), (3, 3), (9, 5))))