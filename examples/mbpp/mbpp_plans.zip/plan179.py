def check_distinct(input_tuple: tuple) -> bool:
    # Convert the tuple to a set
    unique_elements = set(input_tuple)
    
    # Compare the length of the set with the length of the tuple
    return len(unique_elements) == len(input_tuple)