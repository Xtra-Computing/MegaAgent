from typing import List

def check_greater(array: List[int], number: int) -> bool:
    # Check if the array is empty
    if not array:
        return False
    
    # Iterate through each element in the array
    for element in array:
        # If the number is less than or equal to any element, return False
        if number <= element:
            return False
    
    # If the loop completes, return True
    return True
