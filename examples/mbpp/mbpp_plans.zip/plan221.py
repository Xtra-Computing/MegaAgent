def find_adverb_position(sentence):
    words = sentence.split()
    for word in words:
        # Remove trailing punctuation
        clean_word = word.rstrip('.,!?')
        if clean_word.endswith('ly'):
            start_position = sentence.find(clean_word)
            end_position = start_position + len(clean_word)
            return (start_position, end_position, clean_word)
    return None