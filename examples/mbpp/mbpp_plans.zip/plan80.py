def pancake_sort(arr):
    # Helper function to flip the array till the given index
    def flip(end):
        start = 0
        while start < end:
            arr[start], arr[end] = arr[end], arr[start]
            start += 1
            end -= 1

    # Main function to perform pancake sort
    n = len(arr)
    for curr_size in range(n, 1, -1):
        # Find the index of the maximum element in arr[0..curr_size-1]
        max_index = 0
        for i in range(1, curr_size):
            if arr[i] > arr[max_index]:
                max_index = i

        # Move the maximum element to the end of the current array
        if max_index != curr_size - 1:
            # Flip the maximum number to the front
            flip(max_index)
            # Flip it to the end
            flip(curr_size - 1)

    return arr