from typing import List, Tuple, Any

def extract_nth_element(tuples_list: List[Tuple[Any, ...]], n: int) -> List[Any]:
    # Input Validation
    if not tuples_list:
        raise ValueError("The input list is empty.")
    if not all(len(t) > n for t in tuples_list):
        raise IndexError("Index n is out of range for one or more tuples.")

    # Extraction Process
    result = []
    for t in tuples_list:
        result.append(t[n])

    # Return the Result
    return result
