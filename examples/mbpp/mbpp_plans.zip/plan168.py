from typing import List
import heapq

def large_product(list1: List[int], list2: List[int], n: int) -> List[int]:
    # Step 1: Input Validation
    if not list1 or not list2 or n <= 0:
        return []
    
    # Step 2: Product Calculation
    products = []
    for num1 in list1:
        for num2 in list2:
            products.append(num1 * num2)

    # Step 3: Sorting and Selection
    # Use a heap to efficiently get the n largest products
    largest_products = heapq.nlargest(n, products)

    # Step 4: Return
    return largest_products
