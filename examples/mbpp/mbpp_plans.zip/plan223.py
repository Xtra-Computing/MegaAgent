def positive_count(numbers):
    """
    Calculate the ratio of positive numbers in a list.

    Parameters:
    numbers (list of int): A list of integers.

    Returns:
    float: The ratio of positive numbers rounded to two decimal places.
    """
    if not numbers:
        return 0.0
    positive_numbers = [num for num in numbers if num > 0]
    ratio = len(positive_numbers) / len(numbers)
    return round(ratio, 2)