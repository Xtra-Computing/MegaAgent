def max_aggregate(scores):
    # Initialize a dictionary to store aggregate scores for each name
    aggregate_scores = {}
    
    # Iterate over the list of tuples
    for name, score in scores:
        if name in aggregate_scores:
            aggregate_scores[name] += score
        else:
            aggregate_scores[name] = score
    
    # Determine the name with the maximum aggregate score
    max_name = None
    max_score = 0
    for name, total_score in aggregate_scores.items():
        if total_score > max_score:
            max_name = name
            max_score = total_score
    
    # Return the result as a tuple
    return (max_name, max_score)