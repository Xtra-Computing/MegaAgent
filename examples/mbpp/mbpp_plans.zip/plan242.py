from itertools import combinations

# Function to generate all possible combinations of a list
def combinations_list(elements):
    # Sort elements to ensure combinations are generated in lexicographical order
    elements.sort()
    # Start with an empty list in the result
    result = [[]]
    # Iterate over all possible lengths of combinations
    for r in range(1, len(elements) + 1):
        # Generate combinations of the current length
        for combo in combinations(elements, r):
            # Append each combination as a list to the result
            result.append(list(combo))
    # Sort the result by length and then lexicographically
    result.sort(key=lambda x: (len(x), x))
    return result
