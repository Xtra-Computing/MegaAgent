def is_octagonal(n: int) -> int:
    if not isinstance(n, int) or n <= 0:
        raise ValueError("Input must be a positive integer.")
    return n * (3 * n - 2)