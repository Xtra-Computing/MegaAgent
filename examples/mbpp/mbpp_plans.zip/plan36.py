def closest_num(n: int) -> int:
    """
    Returns the closest smaller integer than the given positive integer n.

    Parameters:
    n (int): A positive integer

    Returns:
    int: The closest smaller integer
    """
    return n - 1
