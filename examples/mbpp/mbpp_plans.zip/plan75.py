def hexagonal_num(n: int) -> int:
    """
    Calculate the nth hexagonal number.

    Parameters:
    n (int): The position of the hexagonal number to calculate.

    Returns:
    int: The nth hexagonal number.
    """
    return n * (2 * n - 1)
