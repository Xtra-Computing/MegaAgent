from typing import List

def is_Monotonic(arr: List[int]) -> bool:
    # Handle edge cases
    if len(arr) <= 1:
        return True

    # Initialize flags for monotonicity
    is_non_decreasing = True
    is_non_increasing = True

    # Check the monotonicity of the array
    for i in range(1, len(arr)):
        if arr[i] > arr[i - 1]:
            is_non_increasing = False
        if arr[i] < arr[i - 1]:
            is_non_decreasing = False

    # Return True if the array is either non-decreasing or non-increasing
    return is_non_decreasing or is_non_increasing
