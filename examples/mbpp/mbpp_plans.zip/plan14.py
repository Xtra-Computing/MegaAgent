from typing import List, Tuple

def max_difference(tuple_list: List[Tuple[int, int]]) -> int:
    max_diff = 0
    for a, b in tuple_list:
        diff = abs(a - b)
        if diff > max_diff:
            max_diff = diff
    return max_diff
