def next_power_of_2(n):
    if n == 0:
        return 1
    
    # If n is already a power of 2, return n
    if (n & (n - 1)) == 0:
        return n
    
    # Find the next power of 2
    power = 1
    while power < n:
        power <<= 1
    return power
