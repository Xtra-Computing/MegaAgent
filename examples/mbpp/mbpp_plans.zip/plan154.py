def count_no_of_ways(n: int, k: int) -> int:
    if n == 0:
        return 0
    if n == 1:
        return k
    
    # Initialize base cases
    same = [0] * n
    diff = [0] * n
    
    same[0] = 0
    diff[0] = k
    
    for i in range(1, n):
        same[i] = diff[i-1]
        diff[i] = (same[i-1] + diff[i-1]) * (k - 1)
    
    return same[n-1] + diff[n-1]
