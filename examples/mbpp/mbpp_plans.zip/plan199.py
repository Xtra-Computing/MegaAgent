def group_tuples(tuples_list):
    grouped = {}
    for first, second in tuples_list:
        if first not in grouped:
            grouped[first] = []
        grouped[first].append(second)
    
    result = []
    for first in grouped:
        result.append((first, *grouped[first]))
    return result
