def check_char(s: str) -> str:
    # Check for Empty String
    if not s:
        return "Invalid"
    
    # Single Character String
    if len(s) == 1:
        return "Valid"
    
    # General Case
    if s[0] == s[-1]:
        return "Valid"
    else:
        return "Invalid"
