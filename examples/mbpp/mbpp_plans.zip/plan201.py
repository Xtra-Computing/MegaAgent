def round_and_sum(numbers):
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list")
    if not numbers:
        return 0
    rounded_numbers = [round(num) for num in numbers]
    total_sum = sum(rounded_numbers)
    result = total_sum * len(numbers)
    return result
