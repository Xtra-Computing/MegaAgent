def odd_values_string(s: str) -> str:
    # Initialize an empty result string
    result = ''
    
    # Iterate over the string
    for i in range(len(s)):
        # Check if the index is even
        if i % 2 == 0:
            # Append the character to the result string
            result += s[i]
    
    # Return the result string
    return result
