def check(number: int) -> bool:
    # Reverse the digits of the number
    reversed_number = int(str(number)[::-1])
    
    # Calculate twice the reversed number
    twice_reversed = 2 * reversed_number
    
    # Check if the original number is one less than twice the reversed number
    return number == twice_reversed - 1
