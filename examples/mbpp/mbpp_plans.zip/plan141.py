import math

def volume_cylinder(radius: float, height: float) -> float:
    """
    Calculate the volume of a cylinder given its radius and height.

    Parameters:
    radius (float): The radius of the cylinder's base. Must be a non-negative float.
    height (float): The height of the cylinder. Must be a non-negative float.

    Returns:
    float: The volume of the cylinder.
    """
    return math.pi * radius ** 2 * height
