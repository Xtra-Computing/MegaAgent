from typing import List

def larg_nnum(input_list: List[int], n: int) -> List[int]:
    # Input Validation
    if not input_list or n <= 0:
        return []
    
    # Extract Unique Values
    unique_values = set(input_list)
    
    # Sort Values
    sorted_values = sorted(unique_values, reverse=True)
    
    # Select Top n Values
    top_n_values = sorted_values[:n]
    
    # Return Result
    return top_n_values
