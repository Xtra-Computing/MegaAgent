def perimeter_pentagon(side_length: int) -> int:
    return side_length * 5
