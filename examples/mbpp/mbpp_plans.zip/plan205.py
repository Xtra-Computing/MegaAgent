def extract_rear(strings: tuple) -> list:
    # Initialize an empty list to store the last characters
    last_characters = []
    
    # Iterate over each string in the tuple
    for string in strings:
        # Append the last character of the string to the list
        last_characters.append(string[-1])
    
    # Return the list of last characters
    return last_characters
