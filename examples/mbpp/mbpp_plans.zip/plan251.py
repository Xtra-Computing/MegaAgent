def replace_char(input_string: str, target_char: str, replacement_char: str) -> str:
    # Use the replace method to replace target_char with replacement_char
    return input_string.replace(target_char, replacement_char)