def comb_sort(arr):
    """
    Sorts a list using the Comb Sort algorithm.

    Parameters:
    arr (list): The list of elements to be sorted.

    Returns:
    list: A new list with the elements sorted in ascending order.
    """
    def get_next_gap(gap):
        # Shrink gap by shrink factor of 1.3
        gap = int(gap / 1.3)
        if gap < 1:
            return 1
        return gap

    n = len(arr)
    gap = n
    swapped = True

    while gap != 1 or swapped:
        gap = get_next_gap(gap)
        swapped = False

        for i in range(n - gap):
            if arr[i] > arr[i + gap]:
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                swapped = True

    return arr
