def first_non_repeating_character(s: str) -> str:
    """
    Find the first non-repeated character in a given string.

    Parameters:
    s (str): The input string containing any printable ASCII characters.

    Returns:
    str: The first non-repeated character in the string, or None if all characters are repeated.
    """
    # Step 1: Use a dictionary to count occurrences of each character
    char_count = {}
    for char in s:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1

    # Step 2: Find the first character with a count of 1
    for char in s:
        if char_count[char] == 1:
            return char

    # Step 3: If no non-repeated character is found, return None
    return None