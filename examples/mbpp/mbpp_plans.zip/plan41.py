from typing import List, Tuple

def index_minimum(tuples_list: List[Tuple[str, int]]) -> str:
    # Assume the first tuple has the smallest second value initially
    smallest_tuple = tuples_list[0]
    
    # Iterate through the list of tuples
    for current_tuple in tuples_list:
        # Compare the second element of each tuple with the current smallest value
        if current_tuple[1] < smallest_tuple[1]:
            # Update the smallest tuple if a smaller second value is found
            smallest_tuple = current_tuple
    
    # Return the first element of the tuple with the smallest second value
    return smallest_tuple[0]