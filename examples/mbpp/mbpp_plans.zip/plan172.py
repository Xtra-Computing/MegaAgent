import math

def volume_cone(radius, height):
    """
    Calculate the volume of a cone given its radius and height.

    Parameters:
    radius (int or float): The radius of the base of the cone.
    height (int or float): The height of the cone.

    Returns:
    float: The volume of the cone.
    """
    return (1/3) * math.pi * radius**2 * height
