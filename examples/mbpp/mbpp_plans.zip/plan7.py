def is_woodall(n: int) -> bool:
    if n <= 0:
        return False
    
    k = 1
    while True:
        woodall_number = k * (2 ** k) - 1
        if woodall_number == n:
            return True
        elif woodall_number > n:
            return False
        k += 1
