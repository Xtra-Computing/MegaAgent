def sort_sublists(list_of_lists):
    # Create a new list to store the sorted sublists
    sorted_list_of_lists = []
    
    # Iterate through each sublist in the input list
    for sublist in list_of_lists:
        # Sort the sublist and append it to the new list
        sorted_list_of_lists.append(sorted(sublist))
    
    # Return the new list of sorted sublists
    return sorted_list_of_lists
