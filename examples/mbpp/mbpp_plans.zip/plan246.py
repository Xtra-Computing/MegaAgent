def max_product(arr):
    n = len(arr)
    if n == 0:
        return 0

    # Initialize maximum product for each element
    max_product = [0] * n

    # Initialize result
    result = 0

    # Compute maximum product for each element
    for i in range(n):
        max_product[i] = arr[i]
        for j in range(i):
            if arr[i] > arr[j]:
                max_product[i] = max(max_product[i], max_product[j] * arr[i])
        result = max(result, max_product[i])

    return result
