def count_X(input_tuple: tuple, element: int) -> int:
    # Initialize a counter
    count = 0
    # Iterate over the tuple
    for item in input_tuple:
        # Compare each item
        if item == element:
            # Increment the counter
            count += 1
    # Return the counter
    return count
