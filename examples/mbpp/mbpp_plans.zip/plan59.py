def tuple_to_int(input_tuple):
    """
    Convert a tuple of positive integers into a single integer by concatenating them.

    Parameters:
    input_tuple (tuple): A tuple containing positive integers.

    Returns:
    int: A single integer formed by concatenating the integers in the input tuple.
    """
    # Convert each integer in the tuple to a string and join them
    concatenated_string = ''.join(map(str, input_tuple))
    
    # Convert the concatenated string back to an integer
    return int(concatenated_string)

# Unit tests
assert tuple_to_int((1, 2, 3)) == 123
assert tuple_to_int((4, 5, 6)) == 456
assert tuple_to_int((5, 6, 7)) == 567
