def start_withp(words_list):
    # Initialize an empty list to store words that start with 'p'
    p_words = []
    
    # Iterate over each string in the input list
    for string in words_list:
        # Split the string into individual words
        words = string.split()
        
        # Check each word to see if it starts with the letter 'p'
        for word in words:
            if word.lower().startswith('p'):
                p_words.append(word)
                
            # Break early if we have found two words
            if len(p_words) == 2:
                return tuple(p_words)
    
    # Return the words found as a tuple (even if less than two)
    return tuple(p_words)