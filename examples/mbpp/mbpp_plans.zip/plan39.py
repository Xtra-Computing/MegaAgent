def is_undulating(number: int) -> bool:
    """
    Check if the given number is undulating.

    An undulating number is a number that has at least two different digits and the digits alternate.
    For example, 1212121 is undulating, but 1991 is not.

    :param number: The number to check.
    :return: True if the number is undulating, False otherwise.
    """
    # Convert the number to a string and ignore the sign
    num_str = str(abs(number))
    
    # If the number has less than 2 digits, it cannot be undulating
    if len(num_str) < 2:
        return False
    
    # Get the first two digits
    first_digit = num_str[0]
    second_digit = num_str[1]
    
    # If the first two digits are the same, it cannot be undulating
    if first_digit == second_digit:
        return False
    
    # Check the alternating pattern
    for i in range(2, len(num_str)):
        if i % 2 == 0:
            if num_str[i] != first_digit:
                return False
        else:
            if num_str[i] != second_digit:
                return False
    
    return True

# Test cases
assert is_undulating(1212121) == True
assert is_undulating(1991) == False
assert is_undulating(121) == True
