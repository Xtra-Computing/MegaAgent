def count_Occurrence(tup, lst):
    counter = 0
    for element in lst:
        counter += tup.count(element)
    return counter
