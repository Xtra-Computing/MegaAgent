def count_integer(lst):
    count = 0
    for element in lst:
        if type(element) is int:
            count += 1
    return count
