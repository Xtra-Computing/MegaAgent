def count_Substrings(s):
    # Initialize counter for valid substrings
    count = 0
    
    # Iterate over all possible starting points of substrings
    for start in range(len(s)):
        # Initialize sum of digits for the current substring
        current_sum = 0
        
        # Iterate over all possible ending points of substrings
        for end in range(start, len(s)):
            # Add the current digit to the sum
            current_sum += int(s[end])
            
            # Calculate the length of the current substring
            length = end - start + 1
            
            # Check if the sum of digits equals the length of the substring
            if current_sum == length:
                count += 1
    
    # Return the total count of valid substrings
    return count
