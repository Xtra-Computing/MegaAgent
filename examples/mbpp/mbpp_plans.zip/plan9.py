from typing import List

def find_Max_Num(digits: List[int]) -> int:
    # Convert each integer to a string
    str_digits = list(map(str, digits))
    
    # Sort the string digits in descending order
    str_digits.sort(reverse=True)
    
    # Join the sorted string digits into a single string
    largest_num_str = ''.join(str_digits)
    
    # Convert the concatenated string back to an integer
    largest_num = int(largest_num_str)
    
    return largest_num
