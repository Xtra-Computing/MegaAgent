def find_lucas(n: int) -> int:
    # Base cases
    if n == 0:
        return 2
    elif n == 1:
        return 1
    
    # Start with the first two Lucas numbers
    prev2, prev1 = 2, 1
    
    # Calculate the nth Lucas number
    for _ in range(2, n + 1):
        current = prev1 + prev2
        prev2, prev1 = prev1, current
    
    return current