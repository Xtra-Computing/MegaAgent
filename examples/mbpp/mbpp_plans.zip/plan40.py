def power(a, b):
    """
    Calculate the value of `a` raised to the power of `b`.

    Parameters:
    a (int): The base number.
    b (int): The exponent.

    Returns:
    int: The result of `a` raised to the power of `b`.
    """
    result = 1
    for _ in range(b):
        result *= a
    return result
