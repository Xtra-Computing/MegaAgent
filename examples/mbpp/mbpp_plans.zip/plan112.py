def count_charac(input_string: str) -> int:
    """
    Counts the total number of characters in a given string.

    Parameters:
    input_string (str): The string to count characters in.

    Returns:
    int: The total number of characters in the input string.
    """
    return len(input_string)
