from typing import List

def max_sum_increasing_subseq(arr: List[int], n: int, i: int, k: int) -> int:
    # Initialize the dp array
    dp = [0] * n
    
    # Base case
    dp[0] = arr[0]
    
    # Fill dp array for elements up to index i
    for j in range(1, i + 1):
        for m in range(j):
            if arr[m] < arr[j]:
                dp[j] = max(dp[j], dp[m] + arr[j])
    
    # Ensure the kth element is included
    for m in range(i + 1):
        if arr[m] < arr[k]:
            dp[k] = max(dp[k], dp[m] + arr[k])
    
    return dp[k]
