def count_samepair(list1: list, list2: list, list3: list) -> int:
    # Ensure all lists are of the same length
    if not (len(list1) == len(list2) == len(list3)):
        raise ValueError("All lists must be of the same length.")
    
    # Initialize counter for identical positions
    identical_count = 0
    
    # Iterate through the lists and compare elements
    for i in range(len(list1)):
        if list1[i] == list2[i] == list3[i]:
            identical_count += 1
    
    return identical_count
