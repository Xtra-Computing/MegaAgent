from typing import List

def filter_oddnumbers(numbers: List[int]) -> List[int]:
    """
    Filters out odd numbers from a given list of integers.

    Parameters:
    numbers (List[int]): A list of integers.

    Returns:
    List[int]: A list containing only the odd numbers from the input list.
    """
    return [number for number in numbers if number % 2 != 0]