from typing import List, Tuple, Set

def extract_singly(list_of_tuples: List[Tuple[int, ...]]) -> Set[int]:
    unique_numbers = set()
    for tuple_ in list_of_tuples:
        for number in tuple_:
            unique_numbers.add(number)
    return unique_numbers
