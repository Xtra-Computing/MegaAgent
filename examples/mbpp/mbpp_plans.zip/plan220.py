def multiple_to_single(numbers):
    # Step 1: Input Validation
    if not numbers:
        return 0

    # Step 2: Concatenation Logic
    result = ''
    for number in numbers:
        result += str(number)

    # Step 3: Return the Result
    return int(result)

# Test cases
assert multiple_to_single([11, 33, 50]) == 113350
assert multiple_to_single([-1, 2, 3, 4, 5, 6]) == -123456
assert multiple_to_single([10, 15, 20, 25]) == 10152025
