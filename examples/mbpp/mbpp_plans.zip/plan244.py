def check_value(dictionary: dict, value: any) -> bool:
    # Step 1: Check if the dictionary is empty
    if not dictionary:
        return False
    
    # Step 2: Iterate through the dictionary values
    for val in dictionary.values():
        # Step 3: Compare each value
        if val != value:
            return False
    
    # Step 4: Return result
    return True
