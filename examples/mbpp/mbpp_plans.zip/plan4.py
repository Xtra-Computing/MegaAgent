def square_perimeter(side_length: int) -> int:
    # Calculate the perimeter of the square
    return 4 * side_length
