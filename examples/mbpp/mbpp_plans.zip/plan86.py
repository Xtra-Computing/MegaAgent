def sum_series(n):
    total_sum = 0
    for i in range(n // 2 + 1):
        term = n - 2 * i
        if term > 0:
            total_sum += term
        else:
            break
    return total_sum